Test01 Information
---------------------------------------
Memory size: 2000kb

Input File: input.txt

Paging:
The size of the pages are determined from the output file name
Example: 'pag400.out' - 400kb page size